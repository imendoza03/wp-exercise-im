# Exercise Woocommerce :

 - Install and configure Woocommerce plugin
 - Define the shop needs and configure Woocommerce options
 - Define regional and shipping settings
 - Create some products and categories

## Product classes

 - Create 5 products with different classes
 - Mug (fixed product)
 - T-shirt (variable product : 3 sizes, 5 colors)
 - Photo frame (3 sizes, 2 thickness)
 
## Woocommerce plugins

 - Add some functionnalities to your shop
 - Paiement gateway
 - Configurable Products
 - Ticket/reservation
 - PDF invoices, batch editing, translations...
